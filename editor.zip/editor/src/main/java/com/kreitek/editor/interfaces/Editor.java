package com.kreitek.editor.interfaces;

public interface Editor {
    void run();
}
