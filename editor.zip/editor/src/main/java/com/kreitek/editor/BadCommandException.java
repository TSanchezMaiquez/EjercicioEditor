package com.kreitek.editor;

public class BadCommandException extends Throwable {

}
